import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class Teacher extends User {

    protected String number;
    protected String name;

    public void Tea(String number,String name) throws IOException, SQLException, ClassNotFoundException {
        //Welcome
        this.number=number;
        this.name=name;
        System.out.println(name+"老师，欢迎进入西二作业考核系统！");
        //function
        while(true)
        {
            function();
        }
    }

    private void function() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        Check check=new Check();
        Homework homework=new Homework();
        System.out.println("查看所有考核信息请输入“1”，修改考核信息请输入“2”，增加考核信息请输入“3”，检查作业请输入“4”,查看所有同学审核情况请输入“5”，退出程序请输入“6”：");
        int flag=scanner.nextInt();
        if(flag==1)//查看所有考核信息
        {
            check.seeall();
        }
        else if(flag==2)//修改考核信息
        {
            check.modify();
        }
        else if(flag==3)//增加考核信息
        {
            check.add();
        }
        else if(flag==4)//检查作业
        {
            homework.check();
        }
        else if (flag==5)//查看所有同学审核情况
        {
            Mysql mysql=new Mysql();
            mysql.seeallstudent();
        }
        else if(flag==6)
        {
            Main.Start();
        }
    }


}
