import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Check {
    protected static List<String> checkinformation=new ArrayList<>();
    public static Mysql mysql=new Mysql();

    public void seeall() throws SQLException, ClassNotFoundException {
        mysql.seeallcheck();
    }

    public void modify() throws SQLException, ClassNotFoundException {
        mysql.modifycheck();
    }

    public void  add() throws SQLException, ClassNotFoundException {
        mysql.addcheck();
    }
}
