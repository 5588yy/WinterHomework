import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class Student {
    String number;
    String name;
    public void Stu(String number,String name) throws IOException, SQLException, ClassNotFoundException {
        //Welcome
        this.name=name;
        this.number=number;
        System.out.println(name+"同学，欢迎进入西二作业考核系统！");
        //Function
        while(true)
        {
            function();
        }
    }

    protected void function() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("上传作业请输入“1”，查看所有考核请输入“2”，查看自己的作业状态请输入“3”,退出请输入“4”:");
        Homework homework=new Homework();
        Check check=new Check();
        int flag=scanner.nextInt();
        if(flag==1)
        {
            homework.upload(number);
        }
        else if (flag==2)
        {
            check.seeall();
        }
        else if(flag==3)
        {
            Mysql mysql=new Mysql();
            mysql.seehomework(number);
        }
        else
        {
            Main.Start();
        }
    }
}
