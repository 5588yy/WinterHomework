import javax.net.ssl.SSLContext;
import java.awt.*;
import java.awt.desktop.SystemSleepEvent;
import java.io.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;


public class Homework extends User{
    //变量
    protected String stu_path;
    protected String number;
    //上传作业
    public void upload(String number) throws IOException, SQLException, ClassNotFoundException {
        this.number=number;
        //输入路径
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入作业上传路径：");
        stu_path=scanner.next();
        //复制文件到workpath
        File stu=new File(stu_path);
        File work=new File(workpath+"\\"+number+".zip");
        copyFileUsingFileStreams(stu,work);
        return ;
    }
    //copy file
    private void copyFileUsingFileStreams(File source, File dest)
            throws IOException, SQLException, ClassNotFoundException {
        InputStream input = null;
        OutputStream output = null;
        try {
            input = new FileInputStream(source);
            output = new FileOutputStream(dest);
            byte[] buf = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buf)) > 0) {
                output.write(buf, 0, bytesRead);
            }
        } finally {
            input.close();
            output.close();
        }
        System.out.println("作业已上传到指定文件夹");
        Mysql mysql = new Mysql();
        mysql.uploadmodify(number);
        return ;
    }

    //打开作业文件
    public void check() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        //检查全部或检查单一
        System.out.println("检查某位同学的作业请输入“1”，检查所有已提交作业请输入“2”：");
        int flag=scanner.nextInt();
        if(flag==1)
        {
            String number;
            System.out.println("请输入要检查的学生的学号：");
            number=scanner.next();
            String path;
            path=workpath+"//"+number+".zip";
            File file = new File(path);
            Desktop.getDesktop().open(file);
            Mysql mysql = new Mysql();
            mysql.modifyhomework();
            return ;
        }
        else
        {
            String path;
            path=workpath;
            File file = new File(path);
            Desktop.getDesktop().open(file);
            Mysql mysql = new Mysql();
            mysql.modifyhomework();
            return ;
        }
    }
}
