import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.sql.SQLException;
import java.util.Scanner;

public class Main{

    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        Start();
    }

    public static void Start() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        //Welcome
        System.out.println("欢迎进入作业考核系统！");
        //Login
        Login();
    }

    public static void Login() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        //input the id,name and
        //id
        System.out.print("ID（老师）/学号（学生）：");
        String number;
        number=scanner.next();
        //name
        System.out.print("姓名：");
        String name;
        name=scanner.next();
        //password
        System.out.print("密码：");
        String password;
        password=scanner.next();
        User user=new User();
        user.judge(number,password,name);
    }
}
