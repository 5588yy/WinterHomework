import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.*;

public class User {
    //
    private static String number="000000";
    private static String password="123456";
    protected static String workpath=null;

    public void judge(String number,String password,String name) throws IOException, SQLException, ClassNotFoundException {

        int flag=0;
        //admin
        if (number.equals(this.number))
        {
            flag=1;
            if(password.equals(this.password))
                admin();
            else
            {
                System.out.println("密码错误！");
                Main.Start();
            }
        }
        //student
        Mysql mysql=new Mysql();
        flag=mysql.quesstudent(number,password);
        if(flag==1)
        {
            Student student = new Student();
            student.Stu(number, name);
        }
        //teacher
        flag=mysql.questeacher(number, password);
        if(flag==1)
        {
            Teacher teacher = new Teacher();
            teacher.Tea(number, name);
        }
        //
        if(flag==0)
        {
            System.out.println("用户不存在!");
        }
        else if(flag==2)
            System.out.println("密码错误！");
        Main.Start();
    }

    //管理员模式
    public void admin() throws IOException, SQLException, ClassNotFoundException {
        //Welcome
        System.out.println(this.number+"管理员，欢迎登陆西二作业考核系统");
        //function
        adminfunction();
        return ;
    }

    private void adminfunction() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("更改作业保存路径请输入“1”,添加用户请输入“2”，更改管理员id及密码请输入“3”,查看所有成员信息请输入“4”，退出请输入“5”：");
        int flag;
        flag=scanner.nextInt();
        if(flag==1)
        {
            homeworkpath();
        }
        else if(flag==2)
            addmember();
        else if(flag==3)
            modifyadmin();
        else if(flag==4)
            seeallmember();
        else if(flag==5)
            Main.Start();
        return ;
    }

    //更改作业保存路径
    private void homeworkpath() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        String path;
        System.out.println("输入作业保存路径：");
        path=scanner.next();
        this.workpath=path;
        System.out.println("作业保存路径已更改。");
        return ;
    }

    //添加用户
    private void addmember() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        Mysql mysql=new Mysql();
        System.out.println("添加老师请输入1，添加学生请输入2：");
        int flag=scanner.nextInt();
        if(flag==1)
            mysql.addteacher();
        else if(flag==2)
            mysql.addstudent();
        System.out.println("是否继续添加用户？(yes or no):");
        String flag2=scanner.next();
        if(flag2.equals("yes"))
            addmember();
        return ;
    }

    //修改管理员id与密码
    private void modifyadmin() throws IOException, SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        String number;
        String password;
        System.out.println("请输入修改后的管理员id：");
        number=scanner.next();
        System.out.println("请输入修改后的管理员密码：");
        password=scanner.next();
        this.number=number;
        this.password=password;
        System.out.println("修改成功");
        return ;
    }

    //查看所有成员
    private void seeallmember() throws SQLException, ClassNotFoundException {
        //Teacher
        System.out.println("老师：");
        Mysql mysql=new Mysql();
        mysql.seeallteacher();
        //Student
        System.out.println("学生：");
        mysql.seeallstudent();
        return ;
    }
}
