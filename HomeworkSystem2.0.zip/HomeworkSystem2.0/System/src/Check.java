import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Check {
    protected static List<String> checkinformation=new ArrayList<>();

    public void seeall()
    {
        for(int i=0;i<checkinformation.size();i++)
        {
            System.out.println(i+" "+checkinformation.get(i));
        }
        return ;
    }

    public void seefresh()
    {
        int i=checkinformation.size()-1;
        System.out.println(checkinformation.get(i));
        return ;
    }

    public void modify()
    {
        int max=checkinformation.size()-1;
        System.out.println("请输入要修改的考核信息序号（0~"+max+"):");
        Scanner scanner=new Scanner(System.in);
        int num=scanner.nextInt();
        String freshinf;
        System.out.println("请输入修改后的考核信息：");
        freshinf=scanner.next();
        checkinformation.set(num,freshinf);
        return ;
    }

    public void add()
    {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入要添加的信息：");
        String inf;
        inf=scanner.next();
        checkinformation.add(inf);
        System.out.println("信息添加成功。");
        return ;
    }
}
