import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Mysql {

    protected static String url = "jdbc:mysql://localhost:3306/information?characterEncoding=utf-8";
    protected static String user = "root";
    protected static String password = "yuejianing";
    protected static Connection connection = null;

    public void connected() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url,user,password);
        System.out.println("数据库连接成功" );
        return ;
    }

    public void addstudent() throws SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        connected();
        String name,number,password,homework;
        System.out.println("请输入所添加同学的姓名：");
        name=scanner.next();
        System.out.println("请输入所添加同学的学号：");
        number=scanner.next();
        password="123456";
        homework="未上传";
        //数据库操作
        String sql="insert into student(name,number,password,homework,uptime) values (?,?,'123456','未上传','无')";
        PreparedStatement psql;
        psql = connection.prepareStatement(sql);
        psql.setString(1,name );
        psql.setString(2,number );
        psql.executeUpdate();
        psql.close();
        connection.close();
        //
        System.out.println(name+"同学信息已保存至数据库，初始密码为“123456”。");
        return ;
    }

    public void addteacher() throws SQLException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        connected();
        String number,password;
        System.out.println("请输入所添加老师的ID：");
        number=scanner.next();
        password="012345";
        //数据库操作
        String sql="insert into teacher(number ,password) values (?,'012345')";
        PreparedStatement psql;
        psql = connection.prepareStatement(sql);
        psql.setString(1,number);
        psql.executeUpdate();
        psql.close();
        connection.close();
        //
        System.out.println(number+"老师信息已保存至数据库，初始密码为012345.");
        return ;
    }

    public void modifyhomework() throws SQLException, ClassNotFoundException {
        connected();
        Scanner scanner=new Scanner(System.in);
        String number;
        System.out.println("请输入要修改的同学的学号：");
        number=scanner.next();
        System.out.println("请输入修改后的状态：");
        String homework=scanner.next();
        //数据库操作
        Statement st=connection.createStatement();
        String sql="update student set homework = '"+homework+"' where number = "+number;
        int rows=st.executeUpdate(sql);
        st.close();
        connection.close();
        //
        System.out.println(number+"同学的作业状态已修改。");
        return ;
    }

    //查看所有学生作业状态
    public void seeallstudent() throws SQLException, ClassNotFoundException {
        connected();
        String sql="select * from student";
        Statement st=connection.createStatement();
        ResultSet res=st.executeQuery(sql);
        while(res.next())
        {
            String number=res.getString("number");
            String name=res.getString("name");
            String homework=res.getString("homework");
            String password=res.getString("password");
            String uptime=res.getString("uptime");
            System.out.println(number+" "+" "+name+" "+homework+" "+password+" "+uptime);
        }
        //释放资源
        res.close();
        st.close();
        connection.close();
        return ;
    }

    //查看所有老师信息
    public void seeallteacher() throws SQLException, ClassNotFoundException {
        connected();
        String sql="select * from teacher";
        Statement st=connection.createStatement();
        ResultSet res=st.executeQuery(sql);
        while(res.next())
        {
            String number=res.getString("number");
            String password1=res.getString("password");
            System.out.println(number+" "+password1);
        }
        //释放资源
        res.close();
        st.close();
        connection.close();
        return ;
    }

    //学生查询自己的作业状态
    public void seehomework(String number) throws SQLException, ClassNotFoundException {
        connected();
        String sql="select * from student";
        Statement st=connection.createStatement();
        ResultSet res=st.executeQuery(sql);
        while(res.next())
        {
            String number1=res.getString("number");
            String name=res.getString("name");
            String homework=res.getString("homework");
            if(number1.equals(number))
                System.out.println(number1+" "+" "+name+"同学，你的作业状态为 "+homework);
        }
        //释放资源
        res.close();
        st.close();
        connection.close();
        return ;
    }

    //查询老师
    public int questeacher(String number,String password) throws SQLException, ClassNotFoundException {
        connected();
        String sql="select * from teacher";
        Statement st=connection.createStatement();
        ResultSet res=st.executeQuery(sql);
        while(res.next())
        {
            String number1=res.getString("number");
            String password1=res.getString("password");
            if(number1.equals(number))
            {
                if(password1.equals(password))
                    return 1;//登陆成功
                else
                    return 2;//密码错误
            }
        }
        //释放资源
        res.close();
        st.close();
        connection.close();
        return 0;//用户不存在
    }
    //学生查询
    public int quesstudent(String number,String password) throws SQLException, ClassNotFoundException {
        connected();
        String sql="select * from student";
        Statement st=connection.createStatement();
        ResultSet res=st.executeQuery(sql);
        while(res.next())
        {
            String number1=res.getString("number");
            String password1=res.getString("password");
            if(number1.equals(number))
            {
                if(password1.equals(password))
                    return 1;//登陆成功
                else
                    return 2;//密码错误
            }
        }
        //释放资源
        res.close();
        st.close();
        connection.close();
        return 0;//用户不存在
    }
    //已上传作业修改状态
    public void uploadmodify(String number) throws SQLException, ClassNotFoundException {
        connected();
        //数据库操作
        Statement st=connection.createStatement();
        String sql1="update student set homework = '已上传' where number = "+number;
        Date date=new Date();
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String s1 = df.format(date);
        String sql2="update student set uptime = '"+s1+"' where number = "+number;
        int rows=st.executeUpdate(sql1);
        int rows2=st.executeUpdate(sql2);
        st.close();
        connection.close();
        //
        System.out.println(number+"同学的作业状态已修改。");
        return ;
    }
}
