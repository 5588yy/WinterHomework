import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;

public class User {
    //
    protected static List<String > stu_number=new ArrayList<>();
    protected static Map<String,String> stu_password=new HashMap<>();
    protected static List<String > tea_number=new ArrayList<>();
    protected static Map<String,String> tea_password=new HashMap<>();
    private static String number="000000";
    private static String password="123456";
    protected static String workpath=null;

    public void judge(String number,String password,String name) throws IOException {

        boolean flag=false;
        //admin
        if (number.equals(this.number))
        {
            flag=true;
            if(password.equals(this.password))
                admin();
            else
            {
                System.out.println("密码错误！");
                Main.Start();
            }
        }
        //student
        for(int i=0;i<stu_number.size();i++)
        {
            String nownumber=stu_number.get(i);
            String nowpassword=stu_password.get(nownumber);
            if (number.equals(nownumber))
            {
                flag=true;
                if(nowpassword.equals(password))
                {
                    Student stu=new Student();
                    stu.Stu(number,name);
                }
                else
                {
                    System.out.println("密码错误！");
                    Main.Start();
                }
            }
        }
        //teacher
        for(int i=0;i<tea_number.size();i++)
        {
            String nownumber=tea_number.get(i);
            String nowpassword=tea_password.get(nownumber);
            if (number.equals(nownumber))
            {
                flag=true;
                if(nowpassword.equals(password))
                {
                    Teacher tea=new Teacher();
                    tea.Tea(number,name);
                }
                else
                {
                    System.out.println("密码错误！");
                    Main.Start();
                }
            }
        }
        if(!flag)
        {
            System.out.println("用户不存在!");
        }
        Main.Start();
    }

    //管理员模式
    public void admin() throws IOException {
        //Welcome
        System.out.println(this.number+"管理员，欢迎登陆西二作业考核系统");
        //function
        adminfunction();
        return ;
    }

    private void adminfunction() throws IOException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("更改作业保存路径请输入“1”,添加用户请输入“2”，更改管理员id及密码请输入“3”,查看所有成员信息请输入“4”，退出请输入“5”：");
        int flag;
        flag=scanner.nextInt();
        if(flag==1)
        {
            homeworkpath();
            Homework homework=new Homework();
            homework.set();
        }
        else if(flag==2)
            addmember();
        else if(flag==3)
            modifyadmin();
        else if(flag==4)
            seeallmember();
        else if(flag==5)
            Main.Start();
        return ;
    }

    //更改作业保存路径
    private void homeworkpath() throws IOException {
        Scanner scanner=new Scanner(System.in);
        String path;
        System.out.println("输入作业保存路径：");
        path=scanner.next();
        this.workpath=path;
        System.out.println("作业保存路径已更改。");
        admin();
        return ;
    }

    //添加用户
    private void addmember() throws IOException {
        Scanner scanner=new Scanner(System.in);
        String number;
        String password;
        String name;
        String type;
        //
        System.out.println("请输入姓名：");
        name=scanner.next();
        System.out.println("请输入id：");
        number=scanner.next();
        System.out.println("请输入密码：");
        password=scanner.next();
        System.out.println("该用户是学生还是老师？（teacher or student）:");
        type=scanner.next();
        //
        if(type.equals("teacher"))
        {
            tea_number.add(number);
            tea_password.put(number,password);
            System.out.println("添加老师"+name+"成功");
        }
        else if (type.equals("student"))
        {
            stu_number.add(number);
            stu_password.put(number,password);
            System.out.println("添加学生"+name+"成功");
        }
        else
        {
            System.out.println("输入信息发生错误！");
        }
        System.out.println("是否继续添加用户？(yes or no):");
        String flag=scanner.next();
        if(flag.equals("yes"))
            addmember();
        else
            admin();
        return ;
    }

    //修改管理员id与密码
    private void modifyadmin() throws IOException {
        Scanner scanner=new Scanner(System.in);
        String number;
        String password;
        System.out.println("请输入修改后的管理员id：");
        number=scanner.next();
        System.out.println("请输入修改后的管理员密码：");
        password=scanner.next();
        this.number=number;
        this.password=password;
        System.out.println("修改成功");
        admin();
        return ;
    }

    //查看所有成员
    private void seeallmember() throws IOException {
        //Teacher
        System.out.println("老师：");
        for(int i=0;i<tea_number.size();i++)
        {
            System.out.println(i+" "+tea_number.get(i)+" "+tea_password.get(tea_number.get(i)));
        }
        //Student
        System.out.println("学生：");
        for(int i=0;i<stu_number.size();i++)
        {
            System.out.println(i+" "+stu_number.get(i)+" "+stu_password.get(stu_number.get(i)));
        }
        admin();
        return ;
    }
}
