import javax.net.ssl.SSLContext;
import java.awt.*;
import java.awt.desktop.SystemSleepEvent;
import java.io.*;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;


public class Homework extends User{
    //变量
    protected String stu_path;
    protected static Map<String,String> workprocess=new HashMap<>();
    protected String number;
    public static Map<String,Date> uptime=new HashMap<>();
    //
    public void upload(String number) throws IOException {
        this.number=number;
        //输入路径
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入作业上传路径：");
        stu_path=scanner.next();
        //复制文件到workpath
        File stu=new File(stu_path);
        File work=new File(workpath+"\\"+number+".zip");
        copyFileUsingFileStreams(stu,work);
        //改变文件状态
        workprocess.put(number,"未审核");
        return ;
    }
    //copy file
    private void copyFileUsingFileStreams(File source, File dest)
            throws IOException {
        InputStream input = null;
        OutputStream output = null;
        try {
            input = new FileInputStream(source);
            output = new FileOutputStream(dest);
            byte[] buf = new byte[1024];
            int bytesRead;
            while ((bytesRead = input.read(buf)) > 0) {
                output.write(buf, 0, bytesRead);
            }
        } finally {
            input.close();
            output.close();
        }
        System.out.println("作业已上传到指定文件夹");
        Date date = new Date();
        uptime.put(this.number,date);
        workprocess.put(this.number,"未审核");
        return ;
    }

    //初始化
    public void set()
    {
        for(int i=0;i<stu_number.size();i++)
        {
            if(workprocess.containsKey(stu_number.get(i)))
                continue;
            else
                workprocess.put(stu_number.get(i),"未上传");
        }
        System.out.println("作业系统初始化完成");
    }
    //打开作业文件
    public void check() throws IOException {
        Scanner scanner=new Scanner(System.in);
        //检查全部或检查单一
        System.out.println("检查某位同学的作业请输入“1”，检查所有已提交作业请输入“2”：");
        int flag=scanner.nextInt();
        if(flag==1)
        {
            String number;
            System.out.println("请输入要检查的学生的学号：");
            number=scanner.next();
            String path;
            path=workpath+"//"+number+".zip";
            File file = new File(path);
            Desktop.getDesktop().open(file);
            modifyprogress();
            return ;
        }
        else
        {
            String path;
            path=workpath;
            File file = new File(path);
            Desktop.getDesktop().open(file);
            modifyprogress();
            return ;
        }
    }
    //修改考核状态
    public void modifyprogress()
    {
        Scanner scanner=new Scanner(System.in);
        String number;
        System.out.println("请输入要修改审核状态的学生的学号：");
        number=scanner.next();
        System.out.println("请输入审核状态：审核中/通过/未通过");
        String nowprogress=scanner.next();
        workprocess.put(number,nowprogress);
        return ;
    }

    public void allupload()
    {
        for (int i=0;i<stu_number.size();i++)
        {
            String nownumber=stu_number.get(i);
            String nowprocess=workprocess.get(nownumber);
            System.out.println(nownumber+" "+nowprocess);
        }
        return ;
    }

    public void seeprogress(String number)
    {
        System.out.println(number+" "+workprocess.get(number));
        return ;
    }

    public void seeall()
    {
        for(Map.Entry<String, String> entry : workprocess.entrySet()){
            String nownumber = entry.getKey();
            String nowprogress = entry.getValue();
            System.out.println(nownumber+" "+nowprogress);
            if(workprocess.get(nownumber)!="未上传")
            {
                SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
                System.out.println("上传时间："+dateFormat.format(uptime.get(nownumber)));
            }
            else
            {
                System.out.println();
            }
        }
        return ;
    }
}
