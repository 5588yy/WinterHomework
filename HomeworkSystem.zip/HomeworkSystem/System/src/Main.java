import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Scanner;

public class Main{

    public static void main(String[] args) throws IOException {
        Start();
    }

    public static void Start() throws IOException {
        Scanner scanner = new Scanner(System.in);
        //初始化
        Homework homework=new Homework();
        homework.set();
        //Welcome
        System.out.println("欢迎进入作业考核系统！");
        System.out.println("是否退出系统？（退出请输入“exit”，否则输入“no”）：");
        String flag=scanner.next();
        if(flag.equals("exit")) {
            System.out.println("再见！");
            System.exit(0);
        }
        //Login
        Login();
    }

    public static void Login() throws IOException {
        Scanner scanner = new Scanner(System.in);
        //input the id,name and
        //id
        System.out.print("ID（老师）/学号（学生）：");
        String number;
        number=scanner.next();
        //name
        System.out.print("姓名：");
        String name;
        name=scanner.next();
        //password
        System.out.print("密码：");
        String password;
        password=scanner.next();
        User user=new User();
        user.judge(number,password,name);
    }
}
